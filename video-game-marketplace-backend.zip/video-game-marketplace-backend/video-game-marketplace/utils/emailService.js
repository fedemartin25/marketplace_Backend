async function sendPasswordResetEmail(email) {
    // Simulación de envío de correo electrónico
    console.log(`Password reset email sent to ${email}`);
}

module.exports = sendPasswordResetEmail;